/**
 * Modal dialog and UI handling for Tiny AI Simulation.
 *
 * @module tiny_aisim/ui
 * @copyright 2026 Boban Blagojević
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import Modal from 'core/modal';
import {getStrings} from 'core/str';
import {component, dataAttribute, cardClass, placeholderClass} from './common';

/** Convolution kernels of filter_aisim, as [value, label]. */
const CONV_FILTERS = [
    ['identity', 'Identity (Identitet)'],
    ['box', 'Blur – average (Zamućenje – prosek)'],
    ['gaussian', 'Gaussian blur (Gausovo zamućenje)'],
    ['sharpen', 'Sharpen (Izoštravanje)'],
    ['sobelx', 'Sobel – vertical edges (vertikalne ivice)'],
    ['sobely', 'Sobel – horizontal edges (horizontalne ivice)'],
    ['laplacian', 'Laplacian – all edges (sve ivice)'],
    ['emboss', 'Emboss (Reljef)'],
];

/**
 * Escape HTML special characters for attributes and text.
 *
 * @param {string} str
 * @returns {string}
 */
const escapeHtml = (str) => String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

/**
 * Format simulation title and parameter summary for the editor placeholder.
 *
 * @param {string} simType
 * @param {Object} attrs
 * @param {Object} s Localized strings
 * @returns {{title: string, desc: string, icon: string}}
 */
const formatSummary = (simType, attrs, s) => {
    switch (simType) {
        case 'confusion_matrix':
            return {
                icon: '📊',
                title: s.sim_cm,
                desc: `${s.scenario}: ${attrs.scenario} | ${s.threshold}: ${attrs.threshold}`,
            };
        case 'gradient_descent':
            return {
                icon: '⚡',
                title: s.sim_gd,
                desc: `${s.costfunction}: ${attrs.profile} | α = ${attrs.lr} | w₀ = ${attrs.w0}`,
            };
        case 'regression':
            return {
                icon: '📈',
                title: s.sim_reg,
                desc: `${s.scenario}: ${attrs.dataset} | d = ${attrs.degree} | λ = ${attrs.lambda}`,
            };
        case 'knn_tree':
            return {
                icon: '🌲',
                title: s.sim_knn,
                desc: `${s.modeltype}: ${attrs.model} | ${s.scenario}: ${attrs.dataset} | k = ${attrs.k} | depth = ${attrs.depth}`,
            };
        case 'kmeans':
            return {
                icon: '🎯',
                title: s.sim_km,
                desc: `${s.scenario}: ${attrs.dataset} | K = ${attrs.k}`,
            };
        case 'neural_network':
            return {
                icon: '🧠',
                title: s.sim_nn,
                desc: `${s.scenario}: ${attrs.dataset} | ${s.hiddenlayers}: ${attrs.layers} | ` +
                    `${s.neuronsperlayer}: ${attrs.neurons} | ${attrs.activation} | α = ${attrs.lr}`,
            };
        case 'convolution':
            return {
                icon: '🖼️',
                title: s.sim_conv,
                desc: `${s.image}: ${attrs.image} | ${s.filter}: ${attrs.preset}` +
                    (attrs.target ? ` | ${s.targetfilter}: ${attrs.target}` : ''),
            };
        case 'q_learning':
            return {
                icon: '🤖',
                title: s.sim_ql,
                desc: `${s.gridmap}: ${attrs.map} | α = ${attrs.alpha} | γ = ${attrs.gamma} | ε = ${attrs.epsilon}`,
            };
        case 'data_bias':
            return {
                icon: '⚖️',
                title: s.sim_db,
                desc: `n = ${attrs.n} | ${s.groupshare}: ${attrs.share}% | ${s.testshare}: ${attrs.test}% | k = ${attrs.k}`,
            };
        default:
            return {
                icon: '🤖',
                title: s.pluginname,
                desc: simType,
            };
    }
};

/**
 * Build simulation HTML block for TinyMCE editor.
 *
 * @param {string} simType
 * @param {Object} attrs
 * @param {Object} s Localized strings
 * @returns {string}
 */
const buildSimulationHtml = (simType, attrs, s) => {
    const summary = formatSummary(simType, attrs, s);
    const attrList = [`class="${cardClass}"`, `${dataAttribute}="${simType}"`];

    Object.keys(attrs).forEach((key) => {
        if (attrs[key] !== undefined && attrs[key] !== null && attrs[key] !== '') {
            attrList.push(`data-${key}="${escapeHtml(attrs[key])}"`);
        }
    });

    const placeholder =
        `<div class="${placeholderClass}" contenteditable="false">` +
        `<div class="aisim-ph-icon">${summary.icon}</div>` +
        `<div class="aisim-ph-title">${escapeHtml(summary.title)}</div>` +
        `<div class="aisim-ph-desc">${escapeHtml(summary.desc)}</div>` +
        `<span class="aisim-ph-pill">${escapeHtml(s.doubleclick_hint)}</span>` +
        `</div>`;

    return `<div ${attrList.join(' ')}>${placeholder}</div>`;
};

/**
 * Open the simulation configuration dialog.
 *
 * @param {Object} editor TinyMCE editor instance
 * @param {Element|null} existingNode Existing simulation element if editing
 */
export const openDialog = async(editor, existingNode = null) => {
    const keys = [
        'pluginname', 'dialogtitle', 'insert', 'update', 'cancel',
        'simtype', 'sim_cm', 'sim_gd', 'sim_reg', 'sim_knn', 'sim_km', 'sim_nn', 'sim_conv', 'sim_ql', 'sim_db',
        'scenario', 'threshold', 'costfunction', 'learningrate',
        'initialweight', 'polydegree', 'regularization', 'modeltype',
        'neighbors_k', 'maxdepth', 'clusters_k', 'readonly',
        'hiddenlayers', 'neuronsperlayer', 'activationfn', 'image', 'filter', 'targetfilter', 'notarget',
        'gridmap', 'discount', 'exploration', 'population', 'samplesize', 'groupshare', 'testshare',
        'doubleclick_hint', 'preview', 'placeholder_note',
    ];
    const stringValues = await getStrings(keys.map((key) => ({key, component})));
    const s = Object.fromEntries(keys.map((k, i) => [k, stringValues[i]]));

    const isEdit = Boolean(existingNode);
    // Attribute of the simulation being edited, or the default for a new one.
    const curAttr = (name, fallback) => (existingNode && existingNode.getAttribute(name)) || fallback;
    const curSim = curAttr(dataAttribute, 'confusion_matrix').replace(/-/g, '_');

    const curAttrs = {
        scenario: curAttr('data-scenario', 'quality'),
        threshold: curAttr('data-threshold', '0.50'),
        profile: curAttr('data-profile', 'convex'),
        lr: curAttr('data-lr', '0.10'),
        w0: curAttr('data-w0', '3.50'),
        dataset: curAttr('data-dataset', 'sine'),
        degree: curAttr('data-degree', '3'),
        lambda: curAttr('data-lambda', '0.0'),
        model: curAttr('data-model', 'knn'),
        k: curAttr('data-k', '3'),
        depth: curAttr('data-depth', '3'),
        layers: curAttr('data-layers', '1'),
        neurons: curAttr('data-neurons', '4'),
        activation: curAttr('data-activation', 'tanh'),
        image: curAttr('data-image', 'shapes'),
        preset: curAttr('data-preset', 'identity'),
        target: curAttr('data-target', ''),
        map: curAttr('data-map', 'maze'),
        alpha: curAttr('data-alpha', '0.50'),
        gamma: curAttr('data-gamma', '0.90'),
        epsilon: curAttr('data-epsilon', '0.20'),
        population: curAttr('data-population', 'shifted'),
        n: curAttr('data-n', '200'),
        share: curAttr('data-share', '5'),
        test: curAttr('data-test', '25'),
        readonly: curAttr('data-readonly', '0') === '1',
    };

    const opt = (val, text, selectedVal) =>
        `<option value="${val}"${String(val) === String(selectedVal) ? ' selected' : ''}>${escapeHtml(text)}</option>`;

    const bodyHtml =
        `<div class="tiny-aisim-modal-body">` +
        `<div class="form-group tiny-aisim-form-group">` +
        `<label for="aisim-simtype-select"><strong>${s.simtype}</strong></label>` +
        `<select id="aisim-simtype-select" class="form-control custom-select tiny-aisim-select">` +
        opt('confusion_matrix', s.sim_cm, curSim) +
        opt('gradient_descent', s.sim_gd, curSim) +
        opt('regression', s.sim_reg, curSim) +
        opt('knn_tree', s.sim_knn, curSim) +
        opt('kmeans', s.sim_km, curSim) +
        opt('neural_network', s.sim_nn, curSim) +
        opt('convolution', s.sim_conv, curSim) +
        opt('q_learning', s.sim_ql, curSim) +
        opt('data_bias', s.sim_db, curSim) +
        `</select>` +
        `</div>` +

        // Confusion Matrix Fields.
        `<div class="aisim-panel-group" data-sim="confusion_matrix">` +
        `<div class="form-group tiny-aisim-form-group">` +
        `<label for="aisim-cm-scenario">${s.scenario}</label>` +
        `<select id="aisim-cm-scenario" class="form-control custom-select">` +
        opt('quality', 'Quality Inspection (Industrijska kontrola)', curAttrs.scenario) +
        opt('medical', 'Medical Diagnostic (Medicinska dijagnostika)', curAttrs.scenario) +
        opt('spam', 'Spam Filtering (Detekcija neželjene pošte)', curAttrs.scenario) +
        `</select>` +
        `</div>` +
        `<div class="form-group tiny-aisim-form-group">` +
        `<label for="aisim-cm-threshold">${s.threshold}: <span id="aisim-cm-th-val">${curAttrs.threshold}</span></label>` +
        `<input type="range" id="aisim-cm-threshold" class="custom-range" ` +
        `min="0.10" max="0.90" step="0.05" value="${curAttrs.threshold}">` +
        `</div>` +
        `</div>` +

        // Gradient Descent Fields.
        `<div class="aisim-panel-group" data-sim="gradient_descent" hidden>` +
        `<div class="form-group tiny-aisim-form-group">` +
        `<label for="aisim-gd-profile">${s.costfunction}</label>` +
        `<select id="aisim-gd-profile" class="form-control custom-select">` +
        opt('convex', 'Convex (J(w) = w² - Global Minimum)', curAttrs.profile) +
        opt('nonconvex', 'Non-Convex (Multimodal - Local Minima)', curAttrs.profile) +
        opt('plateau', 'Plateau (Flat region - Slow progress)', curAttrs.profile) +
        `</select>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-gd-lr">${s.learningrate}</label>` +
        `<input type="number" id="aisim-gd-lr" class="form-control" ` +
        `min="0.01" max="1.50" step="0.01" value="${curAttrs.lr}">` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-gd-w0">${s.initialweight}</label>` +
        `<input type="number" id="aisim-gd-w0" class="form-control" ` +
        `min="-5.00" max="5.00" step="0.10" value="${curAttrs.w0}">` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Regression Fields.
        `<div class="aisim-panel-group" data-sim="regression" hidden>` +
        `<div class="form-group tiny-aisim-form-group">` +
        `<label for="aisim-reg-dataset">${s.scenario}</label>` +
        `<select id="aisim-reg-dataset" class="form-control custom-select">` +
        opt('sine', 'Sine Wave with Noise (Sinusni signal sa šumom)', curAttrs.dataset) +
        opt('quadratic', 'Quadratic Trend (Kvadratni trend)', curAttrs.dataset) +
        opt('engine', 'Engine Data (Podaci o motoru)', curAttrs.dataset) +
        `</select>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-reg-degree">${s.polydegree}</label>` +
        `<select id="aisim-reg-degree" class="form-control custom-select">` +
        opt('1', 'Degree 1 (Linear)', curAttrs.degree) +
        opt('2', 'Degree 2 (Quadratic)', curAttrs.degree) +
        opt('3', 'Degree 3 (Cubic)', curAttrs.degree) +
        opt('4', 'Degree 4 (Quartic)', curAttrs.degree) +
        opt('5', 'Degree 5 (Quintic)', curAttrs.degree) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-reg-lambda">${s.regularization}</label>` +
        `<select id="aisim-reg-lambda" class="form-control custom-select">` +
        opt('0.0', 'λ = 0.0 (None)', curAttrs.lambda) +
        opt('0.001', 'λ = 0.001 (Small)', curAttrs.lambda) +
        opt('0.01', 'λ = 0.01 (Medium)', curAttrs.lambda) +
        opt('0.1', 'λ = 0.10 (Strong)', curAttrs.lambda) +
        `</select>` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Decision Boundaries (k-NN & Decision Tree) Fields.
        `<div class="aisim-panel-group" data-sim="knn_tree" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-knn-model">${s.modeltype}</label>` +
        `<select id="aisim-knn-model" class="form-control custom-select">` +
        opt('knn', 'k-Nearest Neighbors (k-NN)', curAttrs.model) +
        opt('tree', 'Decision Tree (Stablo odlučivanja)', curAttrs.model) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-knn-dataset">${s.scenario}</label>` +
        `<select id="aisim-knn-dataset" class="form-control custom-select">` +
        opt('moons', 'Two Moons (Dva polumeseca)', curAttrs.dataset) +
        opt('circles', 'Concentric Circles (Krugovi)', curAttrs.dataset) +
        opt('blobs', 'Gaussian Blobs (Klasteri)', curAttrs.dataset) +
        `</select>` +
        `</div>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-knn-k">${s.neighbors_k}</label>` +
        `<select id="aisim-knn-k" class="form-control custom-select">` +
        opt('1', 'k = 1', curAttrs.k) +
        opt('3', 'k = 3', curAttrs.k) +
        opt('5', 'k = 5', curAttrs.k) +
        opt('7', 'k = 7', curAttrs.k) +
        opt('9', 'k = 9', curAttrs.k) +
        opt('15', 'k = 15', curAttrs.k) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-knn-depth">${s.maxdepth}</label>` +
        `<select id="aisim-knn-depth" class="form-control custom-select">` +
        opt('1', 'Depth 1 (Stump)', curAttrs.depth) +
        opt('2', 'Depth 2', curAttrs.depth) +
        opt('3', 'Depth 3', curAttrs.depth) +
        opt('4', 'Depth 4', curAttrs.depth) +
        opt('5', 'Depth 5', curAttrs.depth) +
        opt('6', 'Depth 6', curAttrs.depth) +
        `</select>` +
        `</div>` +
        `</div>` +
        `</div>` +

        // K-Means Fields.
        `<div class="aisim-panel-group" data-sim="kmeans" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-km-dataset">${s.scenario}</label>` +
        `<select id="aisim-km-dataset" class="form-control custom-select">` +
        opt('blobs3', '3 Clusters (3 klastera)', curAttrs.dataset) +
        opt('blobs4', '4 Clusters (4 klastera)', curAttrs.dataset) +
        opt('uniform', 'Uniform – No Natural Groups (Bez prirodnih grupa)', curAttrs.dataset) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-km-k">${s.clusters_k}</label>` +
        `<select id="aisim-km-k" class="form-control custom-select">` +
        opt('2', 'K = 2', curAttrs.k) +
        opt('3', 'K = 3', curAttrs.k) +
        opt('4', 'K = 4', curAttrs.k) +
        opt('5', 'K = 5', curAttrs.k) +
        opt('6', 'K = 6', curAttrs.k) +
        `</select>` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Perceptron & Neural Network Fields.
        `<div class="aisim-panel-group" data-sim="neural_network" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-nn-dataset">${s.scenario}</label>` +
        `<select id="aisim-nn-dataset" class="form-control custom-select">` +
        opt('linear', 'Linearly Separable (Linearno razdvojivi)', curAttrs.dataset) +
        opt('xor', 'XOR (Ukršteni)', curAttrs.dataset) +
        opt('circles', 'Circle in a Circle (Krug u krugu)', curAttrs.dataset) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-nn-layers">${s.hiddenlayers}</label>` +
        `<select id="aisim-nn-layers" class="form-control custom-select">` +
        opt('0', '0 (Perceptron)', curAttrs.layers) +
        opt('1', '1', curAttrs.layers) +
        opt('2', '2', curAttrs.layers) +
        `</select>` +
        `</div>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-nn-neurons">${s.neuronsperlayer}</label>` +
        `<select id="aisim-nn-neurons" class="form-control custom-select">` +
        [1, 2, 3, 4, 5, 6, 7, 8].map((n) => opt(String(n), String(n), curAttrs.neurons)).join('') +
        `</select>` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-nn-activation">${s.activationfn}</label>` +
        `<select id="aisim-nn-activation" class="form-control custom-select">` +
        opt('tanh', 'tanh', curAttrs.activation) +
        opt('sigmoid', 'sigmoid', curAttrs.activation) +
        opt('relu', 'ReLU', curAttrs.activation) +
        `</select>` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-nn-lr">${s.learningrate}</label>` +
        `<input type="number" id="aisim-nn-lr" class="form-control" ` +
        `min="0.01" max="3.00" step="0.01" value="${curAttrs.lr}">` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Convolution & Image Filters Fields.
        `<div class="aisim-panel-group" data-sim="convolution" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-conv-image">${s.image}</label>` +
        `<select id="aisim-conv-image" class="form-control custom-select">` +
        opt('shapes', 'Shapes (Oblici)', curAttrs.image) +
        opt('stripes', 'Stripes (Pruge)', curAttrs.image) +
        opt('face', 'Smiley (Smajli)', curAttrs.image) +
        opt('noisy', 'Shapes with noise (Oblici sa šumom)', curAttrs.image) +
        `</select>` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-conv-preset">${s.filter}</label>` +
        `<select id="aisim-conv-preset" class="form-control custom-select">` +
        CONV_FILTERS.map(([v, text]) => opt(v, text, curAttrs.preset)).join('') +
        `</select>` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-conv-target">${s.targetfilter}</label>` +
        `<select id="aisim-conv-target" class="form-control custom-select">` +
        opt('', s.notarget, curAttrs.target) +
        CONV_FILTERS.filter(([v]) => v !== 'identity').map(([v, text]) => opt(v, text, curAttrs.target)).join('') +
        `</select>` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Reinforcement Learning (Q-learning) Fields.
        `<div class="aisim-panel-group" data-sim="q_learning" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-ql-map">${s.gridmap}</label>` +
        `<select id="aisim-ql-map" class="form-control custom-select">` +
        opt('maze', 'Maze (Lavirint)', curAttrs.map) +
        opt('cliff', 'Cliff (Litica)', curAttrs.map) +
        opt('treasure', 'Near or far (Blizu ili daleko)', curAttrs.map) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-ql-alpha">${s.learningrate} α</label>` +
        `<input type="number" id="aisim-ql-alpha" class="form-control" min="0.05" max="1" step="0.05" value="${curAttrs.alpha}">` +
        `</div>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-ql-gamma">${s.discount} γ</label>` +
        `<input type="number" id="aisim-ql-gamma" class="form-control" min="0" max="1" step="0.05" value="${curAttrs.gamma}">` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-ql-epsilon">${s.exploration} ε</label>` +
        `<input type="number" id="aisim-ql-epsilon" class="form-control" min="0" max="1" step="0.05" value="${curAttrs.epsilon}">` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Data Split & Bias Fields.
        `<div class="aisim-panel-group" data-sim="data_bias" hidden>` +
        `<div class="form-row">` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-db-population">${s.population}</label>` +
        `<select id="aisim-db-population" class="form-control custom-select">` +
        opt('shifted', 'B behaves differently (B radi drugačije)', curAttrs.population) +
        opt('similar', 'B behaves similarly (B radi slično)', curAttrs.population) +
        `</select>` +
        `</div>` +
        `<div class="col-md-6 form-group tiny-aisim-form-group">` +
        `<label for="aisim-db-n">${s.samplesize}</label>` +
        `<input type="number" id="aisim-db-n" class="form-control" min="40" max="400" step="20" value="${curAttrs.n}">` +
        `</div>` +
        `</div>` +
        `<div class="form-row">` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-db-share">${s.groupshare} (%)</label>` +
        `<input type="number" id="aisim-db-share" class="form-control" min="0" max="50" step="5" value="${curAttrs.share}">` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-db-test">${s.testshare} (%)</label>` +
        `<input type="number" id="aisim-db-test" class="form-control" min="10" max="50" step="5" value="${curAttrs.test}">` +
        `</div>` +
        `<div class="col-md-4 form-group tiny-aisim-form-group">` +
        `<label for="aisim-db-k">${s.neighbors_k}</label>` +
        `<input type="number" id="aisim-db-k" class="form-control" min="1" max="25" step="2" value="${curAttrs.k}">` +
        `</div>` +
        `</div>` +
        `</div>` +

        // Read-only Checkbox.
        `<div class="form-group custom-control custom-checkbox tiny-aisim-form-group mt-3">` +
        `<input type="checkbox" class="custom-control-input" id="aisim-opt-readonly"` +
        (curAttrs.readonly ? ' checked' : '') + `>` +
        `<label class="custom-control-label" for="aisim-opt-readonly">${s.readonly}</label>` +
        `</div>` +

        // Preview Box.
        `<div class="mt-4 pt-3 border-top">` +
        `<label><strong>${s.preview}</strong></label>` +
        `<div id="aisim-preview-container"></div>` +
        `<p class="small text-muted mt-2">${s.placeholder_note}</p>` +
        `</div>` +
        `</div>`;

    const footerHtml =
        `<button type="button" class="btn btn-primary" data-action="submit">` +
        (isEdit ? s.update : s.insert) + `</button>` +
        `<button type="button" class="btn btn-secondary" data-action="cancel">${s.cancel}</button>`;

    const modal = await Modal.create({
        title: s.dialogtitle,
        body: bodyHtml,
        footer: footerHtml,
        large: true,
        show: true,
        removeOnClose: true,
    });

    const root = modal.getRoot()[0];
    const simSelect = root.querySelector('#aisim-simtype-select');
    const panels = root.querySelectorAll('.aisim-panel-group');
    const previewContainer = root.querySelector('#aisim-preview-container');

    const cmThRange = root.querySelector('#aisim-cm-threshold');
    const cmThVal = root.querySelector('#aisim-cm-th-val');

    /**
     * Gather currently selected attributes from form.
     *
     * @returns {{simType: string, attrs: Object}}
     */
    const getFormData = () => {
        const simType = simSelect.value;
        const attrs = {
            readonly: root.querySelector('#aisim-opt-readonly').checked ? '1' : '0',
        };

        if (simType === 'confusion_matrix') {
            attrs.scenario = root.querySelector('#aisim-cm-scenario').value;
            attrs.threshold = parseFloat(root.querySelector('#aisim-cm-threshold').value).toFixed(2);
        } else if (simType === 'gradient_descent') {
            attrs.profile = root.querySelector('#aisim-gd-profile').value;
            attrs.lr = parseFloat(root.querySelector('#aisim-gd-lr').value || '0.10').toFixed(2);
            attrs.w0 = parseFloat(root.querySelector('#aisim-gd-w0').value || '3.50').toFixed(2);
        } else if (simType === 'regression') {
            attrs.dataset = root.querySelector('#aisim-reg-dataset').value;
            attrs.degree = root.querySelector('#aisim-reg-degree').value;
            attrs.lambda = root.querySelector('#aisim-reg-lambda').value;
        } else if (simType === 'knn_tree') {
            attrs.model = root.querySelector('#aisim-knn-model').value;
            attrs.dataset = root.querySelector('#aisim-knn-dataset').value;
            attrs.k = root.querySelector('#aisim-knn-k').value;
            attrs.depth = root.querySelector('#aisim-knn-depth').value;
        } else if (simType === 'kmeans') {
            attrs.dataset = root.querySelector('#aisim-km-dataset').value;
            attrs.k = root.querySelector('#aisim-km-k').value;
        } else if (simType === 'neural_network') {
            attrs.dataset = root.querySelector('#aisim-nn-dataset').value;
            attrs.layers = root.querySelector('#aisim-nn-layers').value;
            attrs.neurons = root.querySelector('#aisim-nn-neurons').value;
            attrs.activation = root.querySelector('#aisim-nn-activation').value;
            attrs.lr = parseFloat(root.querySelector('#aisim-nn-lr').value || '0.30').toFixed(2);
        } else if (simType === 'convolution') {
            attrs.image = root.querySelector('#aisim-conv-image').value;
            attrs.preset = root.querySelector('#aisim-conv-preset').value;
            attrs.target = root.querySelector('#aisim-conv-target').value;
        } else if (simType === 'q_learning') {
            const num = (id, fallback) => parseFloat(root.querySelector(id).value || fallback).toFixed(2);
            attrs.map = root.querySelector('#aisim-ql-map').value;
            attrs.alpha = num('#aisim-ql-alpha', '0.50');
            attrs.gamma = num('#aisim-ql-gamma', '0.90');
            attrs.epsilon = num('#aisim-ql-epsilon', '0.20');
        } else if (simType === 'data_bias') {
            const int = (id, fallback) => String(parseInt(root.querySelector(id).value, 10) || fallback);
            attrs.population = root.querySelector('#aisim-db-population').value;
            attrs.n = int('#aisim-db-n', 200);
            attrs.share = int('#aisim-db-share', 0);
            attrs.test = int('#aisim-db-test', 25);
            attrs.k = int('#aisim-db-k', 5);
        }

        return {simType, attrs};
    };

    /**
     * Update active panel and preview placeholder.
     */
    const updateUi = () => {
        const selectedSim = simSelect.value;
        panels.forEach((p) => {
            if (p.getAttribute('data-sim') === selectedSim) {
                p.removeAttribute('hidden');
            } else {
                p.setAttribute('hidden', 'hidden');
            }
        });

        const {simType, attrs} = getFormData();
        const summary = formatSummary(simType, attrs, s);

        previewContainer.innerHTML =
            `<div class="${placeholderClass}" style="margin: 0.5rem 0;">` +
            `<div class="aisim-ph-icon">${summary.icon}</div>` +
            `<div class="aisim-ph-title">${escapeHtml(summary.title)}</div>` +
            `<div class="aisim-ph-desc">${escapeHtml(summary.desc)}</div>` +
            `<span class="aisim-ph-pill">${escapeHtml(s.doubleclick_hint)}</span>` +
            `</div>`;
    };

    // Event listeners.
    simSelect.addEventListener('change', updateUi);
    root.addEventListener('input', (e) => {
        if (e.target.id === 'aisim-cm-threshold') {
            cmThVal.textContent = parseFloat(cmThRange.value).toFixed(2);
        }
        updateUi();
    });
    root.addEventListener('change', updateUi);

    // Initial sync.
    updateUi();

    // Submit handler.
    root.querySelector('[data-action="submit"]').addEventListener('click', (e) => {
        e.preventDefault();
        const {simType, attrs} = getFormData();
        const newHtml = buildSimulationHtml(simType, attrs, s);

        if (isEdit && existingNode) {
            editor.dom.setOuterHTML(existingNode, newHtml);
        } else {
            editor.insertContent(newHtml);
        }

        modal.destroy();
    });

    // Cancel handler.
    root.querySelector('[data-action="cancel"]').addEventListener('click', (e) => {
        e.preventDefault();
        modal.destroy();
    });
};

